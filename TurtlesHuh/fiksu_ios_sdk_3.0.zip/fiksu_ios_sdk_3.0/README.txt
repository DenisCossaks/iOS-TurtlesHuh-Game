Fiksu iOS SDK 3.0

This directory contains the source code required to integrate your iOS app with
Fiksu.

See the Fiksu Dashboard for more information:
http://dashboard.fiksu.com/tracking_configuration
