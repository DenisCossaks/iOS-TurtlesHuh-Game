## Revision 44531 (2012-09-13)

 * Using new AdSupport.framework for identifierForAdvertising

## Revision 44530 (2012-08-28)

 * Removed OpenUDID support
 * Enabled transmission of new iOS identifiers
 * Disabled HTML5 tracking by default
