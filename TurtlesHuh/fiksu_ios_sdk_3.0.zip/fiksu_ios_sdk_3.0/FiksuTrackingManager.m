//
//  FiksuTrackingManager.m
//
//  Copyright 2012 Fiksu, Inc. All rights reserved.
//

#import "FiksuTrackingManager.h"

#if __has_feature(objc_arc)
#error This file does not use ARC. Please see the installation instructions...
#endif

#define FIKSU_MAC_ADDRESS_SUPPORTED 1
#define FIKSU_UDID_SUPPORTED 1
// In production, we only want to flip once in the lifetime of the app. However, 
// during debugging and integration testing, it can be useful to flip multiple 
// times. Be sure to set it to 1 before generating a version for wide use:
#define FIKSU_MARK_LAUNCHES 1
#define FIKSU_HTML5_TRACKING_ENABLED 0

#include <sys/sysctl.h>
#include <netinet/in.h>

#if FIKSU_MAC_ADDRESS_SUPPORTED
  #include <sys/types.h>
  #include <stdio.h>
  #include <string.h>
  #include <sys/socket.h>
  #include <net/if_dl.h>
  #include <ifaddrs.h>
#endif
#include <CommonCrypto/CommonDigest.h>

#import <AdSupport/AdSupport.h>
#import <SystemConfiguration/SCNetworkReachability.h>

#ifndef IFT_ETHER
  #define IFT_ETHER 0x6
#endif

BOOL networkReachabilityFlags(SCNetworkConnectionFlags *flags) {
  struct sockaddr_in zeroAddress;
  bzero(&zeroAddress, sizeof(zeroAddress));
  zeroAddress.sin_len = sizeof(zeroAddress);
  zeroAddress.sin_family = AF_INET;
  
  // Recover reachability flags
  SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr*)&zeroAddress);
  BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, flags);
  CFRelease(defaultRouteReachability);
  return didRetrieveFlags;
}                                  

@interface NSObject ()
+ (void)uploadEventInBackground:(NSDictionary*)eventInfo;
+ (NSString*)wifiMacAddress;
+ (NSString*)localFiksuID;
+ (NSString*)pasteboardFiksuID;
+ (void)uploadQueuedEvents;
+ (BOOL)ensureFiksuID;
+ (void)storeFiksuID:(NSString*)fiksuID;
+ (void)storeFiksuIDInPasteboard:(NSString*)fiksuID;
+ (void)addPOSTData:(NSDictionary*)eventInfo 
       toURLRequest:(NSMutableURLRequest*)request;
+ (NSString*)parameterString:(NSDictionary*)postDict;
@end

@implementation FiksuTrackingManager

typedef enum {
  kRegistrationEnabled,
  kRegistrationUnreachable,
  kRegistrationDisabled
} RegistrationStatus;

// Uncomment the line below and replace <APPID> with your application's
// 9-digit App Store ID (See step 1 of the instructions on our website:
// http://dashboard.fiksu.com/tracking_configuration ).
const NSString *FiksuAppId = @"542661154";
const NSString *FiksuEventsLock = @"EVENTS_LOCK";
const NSUInteger FiksuPasteboardCount=20;
static BOOL sFiksuRegistering=NO;
static BOOL sFiksuLaunchUploaded=NO;
static NSMutableArray *queuedEvents=nil;

#pragma mark Event Queue and Uploading

+ (void)queueFirstEventInBackground:(NSDictionary*)eventInfo {
  @autoreleasepool {
    @synchronized(FiksuEventsLock) {
      [queuedEvents insertObject:eventInfo atIndex:0];
      [[NSUserDefaults standardUserDefaults] setObject:queuedEvents forKey:@"Fiksu.Events"];
    }
    [self uploadQueuedEvents];
  }
}

+ (void)queueEventInBackground:(NSDictionary*)eventInfo {
  @autoreleasepool {
    @synchronized(FiksuEventsLock) {
      [queuedEvents addObject:eventInfo];
      [[NSUserDefaults standardUserDefaults] setObject:queuedEvents forKey:@"Fiksu.Events"];
    }
    [self uploadQueuedEvents];
  }
}

+ (void)queueEvent:(NSDictionary*)eventInfo 
        firstEvent:(BOOL)firstEvent {   
  if (firstEvent) {
    [self performSelectorInBackground:@selector(queueFirstEventInBackground:)
                           withObject:eventInfo];
  } else {
    [self performSelectorInBackground:@selector(queueEventInBackground:)
                           withObject:eventInfo];    
  }
}

+ (void)uploadEvent:(NSString*)eventType 
           withInfo:(NSDictionary*)eventInfo 
         firstEvent:(BOOL)firstEvent {
  NSMutableDictionary *eventDict = [NSMutableDictionary dictionary];
  if (eventInfo == nil) {
    if (eventType == nil) return;
  } else {
    [eventDict addEntriesFromDictionary:eventInfo];
  }
  [eventDict setObject:eventType forKey:@"event"];
  [self queueEvent:eventDict firstEvent:firstEvent];
}

+ (void)uploadEvent:(NSString *)event 
           withInfo:(NSDictionary *)eventInfo {
  [self uploadEvent:event withInfo:eventInfo firstEvent:NO];
}

+ (void)uploadRegistrationEvent:(NSString *)username {
  NSMutableDictionary *eventInfo = [NSMutableDictionary dictionaryWithCapacity:3];
  if (username != nil) {
    [eventInfo setObject:username forKey:@"username"];
  }
  [self uploadEvent:@"Registration" withInfo:eventInfo];
}

+ (void)uploadPurchaseEvent:(NSString *)username currency:(NSString *)currency {
  NSMutableDictionary *eventInfo = [NSMutableDictionary dictionaryWithCapacity:3];
  if (username != nil) {
    [eventInfo setObject:username forKey:@"username"];
  }
  if (currency != nil) {
    [eventInfo setObject:currency forKey:@"tvalue"];
  }
  [self uploadEvent:@"Purchase" withInfo:eventInfo];
}

+ (void)uploadPurchaseEvent:(NSString *)username price:(double)price currency:(NSString *)currency {
  NSMutableDictionary *eventInfo = [NSMutableDictionary dictionaryWithCapacity:3];
  if (username != nil) {
    [eventInfo setObject:username forKey:@"username"];
  }
  [eventInfo setObject:[NSNumber numberWithDouble:price] forKey:@"fvalue"];
  if (currency != nil) {
    [eventInfo setObject:currency forKey:@"tvalue"];
  }
  [self uploadEvent:@"Purchase" withInfo:eventInfo];
}

#pragma mark Resume status

+ (void)enableResumeEvents {
  [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"Fiksu.SendResumes"];
}

+ (void)disableResumeEvents {
  [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"Fiksu.SendResumes"];
}

+ (BOOL)areResumeEventsEnabled {
  NSNumber *status = [[NSUserDefaults standardUserDefaults] objectForKey:@"Fiksu.SendResumes"];
  // By default, resumes are enabled:
  if (! status) return YES;
  return [status boolValue];
}

+ (void)enableUDIDTransmission {
  [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"Fiksu.SendFiksuA"];  
}

+ (void)disableUDIDTransmission {
  [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"Fiksu.SendFiksuA"];    
}

+ (BOOL)isUDIDTransmissionEnabled {
  NSNumber *status = [[NSUserDefaults standardUserDefaults] objectForKey:@"Fiksu.SendFiksuA"];
  // By default, UDID transmission is enabled:
  if (! status) return YES;
  return [status boolValue];
}

+ (void)enableMACTransmission {
  [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"Fiksu.SendFiksuB"];
}

+ (void)disableMACTransmission {
  [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"Fiksu.SendFiksuB"];  
}

+ (BOOL)isMACTransmissionEnabled {
  NSNumber *status = [[NSUserDefaults standardUserDefaults] objectForKey:@"Fiksu.SendFiksuB"];
  // By default, resumes are enabled:
  if (! status) return YES;
  return [status boolValue];
}

#pragma mark Device Classification

+ (BOOL)isIpad {
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
		return YES;
	}
	return NO;
}

+ (NSString*)deviceMachineType {
 	size_t size;
	
	// Set 'oldp' parameter to NULL to get the size of the data
	// returned so we can allocate appropriate amount of space
	sysctlbyname("hw.machine", NULL, &size, NULL, 0); 
	
	// Allocate the space to store name
	char *name = malloc(size);
	
	// Get the platform name
	sysctlbyname("hw.machine", name, &size, NULL, 0);
	
	// Place name into a string
	NSString *machine = [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
	
	// Done with this
	free(name);
  return machine;
}

+ (NSString *)encodeParam:(const NSString *)value {
	return [(NSString *)CFURLCreateStringByAddingPercentEscapes(
																NULL,
																(CFStringRef)value,
																NULL,
																(CFStringRef)@"!*'();:@&=+$,/?%#[]",
																kCFStringEncodingUTF8 ) autorelease];
}

+ (void)addPOSTData:(NSDictionary*)postDict 
       toURLRequest:(NSMutableURLRequest*)urlRequest {
  NSString *postString = [self parameterString:postDict];
  NSData *requestData = [NSData dataWithBytes:[postString UTF8String] 
                                       length:[postString length]];
  [urlRequest setHTTPMethod:@"POST"];
  [urlRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
  [urlRequest setHTTPBody:requestData];
}

+ (NSString*)parameterString:(NSDictionary*)postDict {
  NSMutableString *postString = [NSMutableString string];
	[postString appendFormat:@"app_name=%@", [FiksuTrackingManager encodeParam:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"]]];
  [postString appendFormat:@"&app_version=%@", [FiksuTrackingManager encodeParam:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]]];
#if FIKSU_UDID_SUPPORTED
  if ([self isUDIDTransmissionEnabled] && [UIDevice instancesRespondToSelector:@selector(uniqueIdentifier)]) {
    NSString *udid = [[UIDevice currentDevice] performSelector:@selector(uniqueIdentifier)];
    [postString appendFormat:@"&udid=%@", [FiksuTrackingManager encodeParam:udid]];
  }
#endif
  Class ASIdentifierManagerClass = NSClassFromString(@"ASIdentifierManager");
  if (ASIdentifierManagerClass) {
    id identifierManager = [ASIdentifierManagerClass sharedManager];
    if ([ASIdentifierManagerClass instancesRespondToSelector:@selector(advertisingIdentifier)]) {
      id adID = [identifierManager performSelector:@selector(advertisingIdentifier)];
      NSString *advertisingID = [adID performSelector:@selector(UUIDString)];
      [postString appendFormat:@"&a_id=%@", [FiksuTrackingManager encodeParam:advertisingID]];
    }
    if ([ASIdentifierManagerClass instancesRespondToSelector:@selector(isAdvertisingTrackingEnabled)]) {
      BOOL adEnabled = (BOOL)[identifierManager performSelector:@selector(isAdvertisingTrackingEnabled)];
      [postString appendFormat:@"&a_enabled=%d", adEnabled];
    }
  }
  if ([UIDevice instancesRespondToSelector:@selector(identifierForVendor)]) {
    id vendID = [[UIDevice currentDevice] performSelector:@selector(identifierForVendor)];
    NSString *vendorID = [vendID performSelector:@selector(UUIDString)];
    [postString appendFormat:@"&v_id=%@", [FiksuTrackingManager encodeParam:vendorID]];
  }
  NSString *hardware = [FiksuTrackingManager deviceMachineType];
  if ([@"i386" isEqualToString:hardware] || [@"x86_64" isEqualToString:hardware]) {
    hardware = [FiksuTrackingManager isIpad] ?  @"iPad Simulator" : @"iPhone Simulator";
  }
	[postString appendFormat:@"&hardware=%@", [FiksuTrackingManager encodeParam:hardware]];
	[postString appendFormat:@"&system_name=%@", [FiksuTrackingManager encodeParam:[[UIDevice currentDevice] systemName]]];
	[postString appendFormat:@"&system_version=%@", [FiksuTrackingManager encodeParam:[[UIDevice currentDevice] systemVersion]]];
	[postString appendFormat:@"&country=%@", [FiksuTrackingManager encodeParam:[[NSLocale currentLocale] objectForKey: NSLocaleCountryCode]]];
#if FIKSU_MAC_ADDRESS_SUPPORTED
  if ([self isMACTransmissionEnabled]) {
    [postString appendFormat:@"&mac=%@", [FiksuTrackingManager encodeParam:[FiksuTrackingManager wifiMacAddress]]];
  }
#endif

  NSString *fiksuID = [FiksuTrackingManager localFiksuID];
  if (fiksuID) {
    [postString appendFormat:@"&fiksuid=%@", [FiksuTrackingManager encodeParam:fiksuID]];
  }

	NSString *lang = @"en";
	NSArray* preferred = [NSLocale preferredLanguages];
	if (preferred && [preferred count] > 0) {
		lang = [preferred objectAtIndex: 0];
	}
	[postString appendFormat:@"&lang=%@", [FiksuTrackingManager encodeParam:lang]];

	NSTimeZone *localTimezone = [NSTimeZone defaultTimeZone];
	[postString appendFormat:@"&timezone=%@", [FiksuTrackingManager encodeParam:[localTimezone name]]];

	NSString *gmtOffset = [NSString stringWithFormat:@"%d", [localTimezone secondsFromGMT]];
	[postString appendFormat:@"&gmtoffset=%@", gmtOffset]; // No need to escape.

	[postString appendFormat:@"&s9=%d", [[NSFileManager defaultManager] fileExistsAtPath:@"/private/var/lib/apt"]]; // No need to escape.

  NSArray *parameters = [NSArray arrayWithObjects:@"username", @"tvalue", @"fvalue", @"ivalue", nil];
  for (NSString *parameter in parameters) {
    id value = [postDict objectForKey:parameter];
    if (value != nil) {
      if ([value isKindOfClass:[NSNumber class]]) {
        // encodeParam needs an NSString
        value = [value stringValue];
      }
      [postString appendFormat:@"&%@=%@", parameter, [FiksuTrackingManager encodeParam:value]];
    }
  }
  return postString;
}

+ (BOOL)performUpload:(NSMutableURLRequest*)urlRequest {
  urlRequest.timeoutInterval = 15.0;
  NSURLResponse *response = nil;
  NSError *error = nil;

  [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:&error];
  NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
  if((!error) && ([httpResponse statusCode] == 200)) {
    NSString *fiksuID = [[httpResponse allHeaderFields] objectForKey:@"Fiksu-Id"];
    if ([fiksuID length] > 0 &&
        (! [[self localFiksuID] length] > 0)) {
      [self storeFiksuID:fiksuID];
    }
    return YES;
  } else if ([httpResponse statusCode] == 400){
    // Return YES, as this request should never be uploaded again:
    return YES;
  }
  return NO;
}

+ (NSMutableURLRequest*)buildUrlRequest:(NSDictionary *)eventDictionary {
  NSString *event = [eventDictionary objectForKey:@"event"];
  NSMutableString *url = [NSMutableString stringWithString:@"https://a.fiksu.com/"];

	NSString *fiksuVersionString = @"$Rev$ 44531";
	NSString *fiksuVersion = [[fiksuVersionString componentsSeparatedByString:@" "] objectAtIndex:1];

	NSString *bundleId = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
  NSString *controllerPath = [NSString stringWithFormat:@"%@/ios/%@/event", 
                              fiksuVersion, bundleId];
	[url appendFormat:@"%@?appid=%@", controllerPath, [FiksuTrackingManager encodeParam:FiksuAppId]];
	[url appendFormat:@"&event=%@", [FiksuTrackingManager encodeParam:event]];

  NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
  [FiksuTrackingManager addPOSTData:eventDictionary toURLRequest:urlRequest];

	return urlRequest;
}

+ (void)uploadQueuedEvents {
#if FIKSU_MARK_LAUNCHES
  // Don't upload anything until we have successfully 
  // communicated with a.fiksu.com
  if (! [self trackedLaunch]) return;
#endif
  @synchronized(FiksuEventsLock) {
    if (queuedEvents != nil) {
      NSArray *remainingEvents = [NSArray arrayWithArray:queuedEvents];
      for (NSDictionary *eventInfo in remainingEvents) {
        NSMutableURLRequest *uploadRequest = [self buildUrlRequest:eventInfo];
        if([self performUpload:uploadRequest]) {
          [queuedEvents removeObject:eventInfo];
          [[NSUserDefaults standardUserDefaults] setObject:queuedEvents forKey:@"Fiksu.Events"];
        }
      }
    }
  }
}

+ (NSURL*)generateHeartbeatURL {
  NSMutableString *heartbeatURLString = [NSMutableString stringWithString:@"https://a.fiksu.com/register/heartbeat?"];
  [heartbeatURLString appendFormat:@"appid=%@", [self encodeParam:FiksuAppId]];
#if FIKSU_MAC_ADDRESS_SUPPORTED
  if ([self isMACTransmissionEnabled]) {
    [heartbeatURLString appendFormat:@"&mac=%@", 
     [FiksuTrackingManager encodeParam:[FiksuTrackingManager wifiMacAddress]]];
  }
#endif
  // Pass in any existing Fiksu ID:
  NSString *fiksuID = [self pasteboardFiksuID];
  if ([fiksuID length] > 0) {
    [heartbeatURLString appendFormat:@"&fiksuid=%@", fiksuID];
  }
  return [NSURL URLWithString:heartbeatURLString];
}

+ (RegistrationStatus)fiksuRegistrationStatus:(NSTimeInterval)timeout isTerminal:(BOOL)terminal {
  // Ensure that ASO is alive to prevent stranding the user in Mobile Safari
  NSURL *testURL = [self generateHeartbeatURL];
  NSURLRequest *testRequest = [NSURLRequest requestWithURL:testURL cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:timeout];
  NSURLResponse* response = nil;
  NSError* error = nil;
  [NSURLConnection sendSynchronousRequest:testRequest
                        returningResponse:&response
                                    error:&error];
  NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
  if((!error) && ([httpResponse statusCode] == 200)) {
    NSDictionary *responseHeader = [httpResponse allHeaderFields];
    // Check the returned 'Fiksu-Id' header to see if there is a fiksuID to store:
    NSString *fiksuID = [responseHeader objectForKey:@"Fiksu-Id"];
    if ([fiksuID length] > 0 &&
        (! [[self localFiksuID] length] > 0)) {
      [self storeFiksuID:fiksuID];
    }
    // Check the returned 'Fiksu-Registration-Status' header to see if 
    // registration was disabled by ASO.
    NSString *enabled = [responseHeader objectForKey:@"Fiksu-Registration-Status"];
    if ([enabled isEqualToString:@"OK"]) {
      return kRegistrationEnabled;
    } else {
      return kRegistrationDisabled;
    }
  } else if (! terminal) {
    return [self fiksuRegistrationStatus:timeout/2.0 isTerminal:YES];
  }
  return kRegistrationUnreachable;
}

+ (RegistrationStatus)registrationStatus  {
  SCNetworkConnectionFlags flags;
  if (! networkReachabilityFlags(&flags)) return kRegistrationUnreachable;
  
  BOOL isReachable = flags & kSCNetworkFlagsReachable;
  BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
  if (!isReachable || needsConnection) return kRegistrationUnreachable;
  return [self fiksuRegistrationStatus:4.0 isTerminal:NO];
}

#if FIKSU_MAC_ADDRESS_SUPPORTED

  + (NSString*)wifiMacAddress {
      // Attribution:
      // http://stackoverflow.com/questions/677530/how-can-i-programmatically-get-the-mac-address-of-an-iphone
      // http://stackoverflow.com/users/154722/shipmaster
      int  success;
      struct ifaddrs * addrs;
      struct ifaddrs * cursor;
      const struct sockaddr_dl * dlAddr;
      const unsigned char* base;
      int i;
      
      // 012345678901234567
      // xx:xx:xx:xx:xx:xx\0
      char* macAddress = (char*)malloc(18);
      const char* ifName = "en0";
      
      success = getifaddrs(&addrs) == 0;
      if (success) {
          cursor = addrs;
          while (cursor != 0) {
              if ( (cursor->ifa_addr->sa_family == AF_LINK)
                  && (((const struct sockaddr_dl *) cursor->ifa_addr)->sdl_type == IFT_ETHER) && strcmp(ifName,  cursor->ifa_name)==0 ) {
                  dlAddr = (const struct sockaddr_dl *) cursor->ifa_addr;
                  base = (const unsigned char*) &dlAddr->sdl_data[dlAddr->sdl_nlen];
                  strcpy(macAddress, "");
                  for (i = 0; i < MIN(dlAddr->sdl_alen, 6); i++) {
                      if (i != 0) {
                          strcat(macAddress, ":");
                      }
                      char partialAddr[3];
                      sprintf(partialAddr, "%02X", base[i]);
                      strcat(macAddress, partialAddr);
                  }
              }
              cursor = cursor->ifa_next;
          }
          freeifaddrs(addrs);
      }
      NSString *objcString = [NSString stringWithCString:macAddress encoding:NSUTF8StringEncoding];
      
      
      free(macAddress);
      
      return objcString;
  }

#endif

+(BOOL)trackedLaunch {
#if FIKSU_MARK_LAUNCHES
  NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
  return [prefs boolForKey:@"Fiksu.facilitated"];
#else
  return NO;
#endif
}

+(void)markTrackedLaunch {
  NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
  [prefs setBool:YES forKey:@"Fiksu.facilitated"];
  [prefs synchronize];
}

+(NSString*)localFiksuID {
  NSString *localID = [[NSUserDefaults standardUserDefaults] stringForKey:@"Fiksu.ID"];
  if (localID) {
    [self storeFiksuIDInPasteboard:localID];
  }
  return localID;
}

+ (NSDictionary*)pasteboardData:(NSString*)pasteboardName 
                 pasteboardType:(NSString*)pasteboardType {
  UIPasteboard *pasteboard = [UIPasteboard pasteboardWithName:pasteboardName create:NO];
  if (! pasteboard) return nil;
  NSData *pasteboardData = [pasteboard dataForPasteboardType:pasteboardType];
  if (pasteboardData) {
    @try {
      return [NSKeyedUnarchiver unarchiveObjectWithData:pasteboardData];
    } @catch (NSException *e) {
      // The data appears to be junk. Bail. Don't overwrite in case the tracking code is outdated and another consumer can make use of the data.
    }
  }
  return nil;
}

+ (NSString*)majorityPasteboardFiksuID {
  NSMutableDictionary *idCandidateCounts = [NSMutableDictionary dictionary];
  NSString *majorityFiksuID = nil;
  NSUInteger majorityCount = 0;
  
  for (NSUInteger i=0; i < FiksuPasteboardCount; i++) {
    NSString *pasteboardName = [NSString stringWithFormat:@"com.fiksu.pb-%d", i];
    NSDictionary *pasteboardData = [self pasteboardData:pasteboardName
                                         pasteboardType:@"com.fiksu.id"];
    if (pasteboardData) {
      NSString *fiksuID = [pasteboardData objectForKey:@"Fiksu.ID"];
      if (fiksuID) {
        NSNumber *candidateCount = [idCandidateCounts objectForKey:fiksuID];
        if (candidateCount) {
          candidateCount = [NSNumber numberWithInteger:[candidateCount integerValue] + 1];
        } else {
          candidateCount = [NSNumber numberWithInteger:1];
        }
        if ([candidateCount integerValue] > majorityCount) {
          majorityFiksuID = fiksuID;
          majorityCount = [candidateCount integerValue];
        }
        [idCandidateCounts setObject:candidateCount forKey:fiksuID];
      }
    }
  }
  return majorityFiksuID;
}

+ (UIPasteboard*)freshPasteboard:(NSData*)owner {
  NSString *eldestPasteboardName = nil;
  NSDate *eldestPasteboardDate = [NSDate date];
  for (NSUInteger i=0; i < FiksuPasteboardCount; i++) {
    NSString *pasteboardName = [NSString stringWithFormat:@"com.fiksu.pb-%d", i];
    NSDictionary *pasteboardData = [self pasteboardData:pasteboardName
                                         pasteboardType:@"com.fiksu.id"];
    if (! pasteboardData) {
      UIPasteboard *pasteboard = [UIPasteboard pasteboardWithName:pasteboardName create:YES];
      pasteboard.persistent = YES;
      return pasteboard;
    }
    NSData *pbOwner = [pasteboardData objectForKey:@"Fiksu.Owner"];
    if (owner && [pbOwner isEqualToData:owner]) {
      // If this app already owns a pasteboard, give it preference:
      return [UIPasteboard pasteboardWithName:pasteboardName create:YES];
    } else {
      NSDate *pasteboardDate = [pasteboardData objectForKey:@"Fiksu.SetTime"];
      if ([pasteboardDate compare:eldestPasteboardDate] == NSOrderedAscending) {
        eldestPasteboardName = pasteboardName;
        eldestPasteboardDate = pasteboardDate;
      }
    }
  }
  [UIPasteboard removePasteboardWithName:eldestPasteboardName];
  return [UIPasteboard pasteboardWithName:eldestPasteboardName create:YES];
}

+ (NSString*)pasteboardFiksuID {
  NSString *appPasteboardName = [NSString stringWithFormat:@"com.fiksu.%@-store", FiksuAppId];
  UIPasteboard *appPasteboard = [UIPasteboard pasteboardWithName:appPasteboardName create:NO];
  if (appPasteboard.string) {
    return appPasteboard.string; 
  }
  return [self majorityPasteboardFiksuID];
}

+ (void)storeFiksuIDInPasteboard:(NSString*)fiksuID {
  NSMutableDictionary *fiksuIDDictionary = [NSMutableDictionary dictionary];
  [fiksuIDDictionary setObject:[NSDate date] forKey:@"Fiksu.SetTime"];
  [fiksuIDDictionary setObject:fiksuID forKey:@"Fiksu.ID"];

  NSData *pasteboardOwner = nil;
  unsigned char digest[CC_SHA1_DIGEST_LENGTH];
  NSData *appIDBytes = [FiksuAppId dataUsingEncoding:NSUTF8StringEncoding];
  if (CC_SHA1([appIDBytes bytes], [appIDBytes length], digest)) {
    pasteboardOwner = [NSData dataWithBytes:digest length:CC_SHA1_DIGEST_LENGTH];
  }
  
  // It is not a bug if pasteboardOwner is nil here -- the LRU pasteboard 
  // will be used:
  [fiksuIDDictionary setObject:pasteboardOwner forKey:@"Fiksu.Owner"];
  UIPasteboard *pasteboard = [self freshPasteboard:pasteboardOwner];
  [pasteboard setValue:[NSKeyedArchiver archivedDataWithRootObject:fiksuIDDictionary]
     forPasteboardType:@"com.fiksu.id"];
  
  NSString *appPasteboardName = [NSString stringWithFormat:@"com.fiksu.%@-store", FiksuAppId];
  UIPasteboard *appPasteboard = [UIPasteboard pasteboardWithName:appPasteboardName create:YES];
  appPasteboard.persistent = YES;
  appPasteboard.string = fiksuID;
}

+ (void)storeFiksuID:(NSString*)fiksuID {
  if ([fiksuID length] == 0) return;
  [[NSUserDefaults standardUserDefaults] setObject:fiksuID forKey:@"Fiksu.ID"];
  [self storeFiksuIDInPasteboard:fiksuID];
}

+ (BOOL)canRegister {
#if ! FIKSU_HTML5_TRACKING_ENABLED
  return NO;
#endif
  
  UIDevice *device = [UIDevice currentDevice];
  if (! device.multitaskingSupported) return NO;
  
  // We need 4.2 for suspend/resume and the handleURL semantics.
  NSString *reqSysVer = @"4.2";
	NSString *currSysVer = [[UIDevice currentDevice] systemVersion];  
	if ([currSysVer compare:reqSysVer options:NSNumericSearch] == NSOrderedAscending) {
		return NO;
	}

  return YES;
}

// Returns YES if the app's launch was handled:
+ (void)openRegistrationPage {
  [self markTrackedLaunch];
  NSMutableString *registrationString = [NSMutableString stringWithString:@"https://a.fiksu.com/register/?"];
  [registrationString appendFormat:@"appid=%@", [self encodeParam:FiksuAppId]];
  srandom(time(NULL));
  [registrationString appendFormat:@"&n=%d", random()];
  sFiksuRegistering = YES;
  [[UIApplication sharedApplication] openURL:[NSURL URLWithString:registrationString]];
}

// Returns NO if no attempt was made to acquire a fiksuID:
+ (BOOL)ensureFiksuID {
  sFiksuLaunchUploaded = YES;
  if ([[self localFiksuID] length] > 0) {
    return NO;
  }
  
  if (! [self canRegister]) {
    // This codepath is hit by devices that can't register, which
    // are older devices that don't support resume or are 
    // running < iOS 4.2

    // We might have a fiksuID stored. Store it now.
    [self storeFiksuID:[self pasteboardFiksuID]];
    // Even if we have a fiksuID, we should still upload the first launch event:
    if (! [self trackedLaunch]) {
      [self markTrackedLaunch];
      // This will generate a fiksuid for us to use:
      [self uploadEvent:@"Conversion" withInfo:nil firstEvent:YES];
      [self uploadEvent:@"Launch" withInfo:nil firstEvent:NO];
      // We return YES since we are generating the fiksuID 
      // with the above launch event:
      return YES;
    }
    return NO;
  }

  // trackedLaunch limits to only one registration attempt.
  // RATIONALE: Make sure we don't leave the client app in the
  // "app-browser-app-loop-of-death" if there is some other unforseen
  // case where handleURL doesn't get called.
  if ([self trackedLaunch]) {
    // Store the fiksuID locally in case we have one:
    [self storeFiksuID:[self pasteboardFiksuID]];
    return NO;
  }
  
  RegistrationStatus status = [self registrationStatus];
  if (status == kRegistrationUnreachable) {
    // Can't reach the server. Try again later:
    return NO;
  } else if (status == kRegistrationDisabled) {
    [self markTrackedLaunch];
    // Store the fiksuID locally in case we have one:
    [self storeFiksuID:[self pasteboardFiksuID]];
    // We never flip in this case:
    return NO;
  }
  
  [self openRegistrationPage];
  // This code should never get executed, but if it does, 
  // we will upload the launch event once we flip back 
  // to the app:
  return YES;
}

+ (void)ensureNotifications {
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(applicationDidBecomeActive:)
                                               name:UIApplicationDidBecomeActiveNotification 
                                             object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(applicationEnteredForeground:) 
                                               name:UIApplicationWillEnterForegroundNotification 
                                             object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(applicationWillResignActive:) 
                                               name:UIApplicationWillResignActiveNotification
                                             object:nil];
}

+ (void)applicationDidBecomeActive:(NSNotification*)notification {
  if (! sFiksuLaunchUploaded) {
    sFiksuLaunchUploaded = YES;
    [self uploadEvent:@"Launch" withInfo:nil];
  }
}

+ (void)applicationEnteredForeground:(NSNotification*)notification {
  if ((! sFiksuRegistering) && [self areResumeEventsEnabled]) {
    [FiksuTrackingManager uploadEvent:@"Resume" withInfo:nil];
  }
}

+ (void)applicationWillResignActive:(NSNotification*)notification {
  // Ensure queued events are written out:
  [[NSUserDefaults standardUserDefaults] setObject:queuedEvents forKey:@"Fiksu.Events"];
}

+ (void)prepareQueuedEvents {
  @synchronized(FiksuEventsLock) {
    NSArray *storedEvents = [[NSUserDefaults standardUserDefaults] arrayForKey:@"Fiksu.Events"];
    if (storedEvents) {
      queuedEvents = [[NSMutableArray alloc] initWithArray:storedEvents];
    } else {
      queuedEvents = [[NSMutableArray alloc] init];
    }
  }
}

+ (void)applicationDidFinishLaunching:(NSDictionary*)launchOptions {
  [self prepareQueuedEvents];
  [self ensureNotifications];
  if (! [self ensureFiksuID]) {
    sFiksuLaunchUploaded = YES;
    // Perform a normal launch event:
    NSString *launchEvent = @"Launch";
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey] != nil) {
      launchEvent = @"NotificationLaunch";
    }
    [self uploadEvent:launchEvent withInfo:nil];
  }
}

+ (BOOL)handleURL:(NSURL*)url sourceApplication:(NSString*)sourceApplication {
  if (!url) { return NO; }
  if (![[url scheme] hasPrefix:@"aso"]) { return NO; }
  if (![sourceApplication isEqualToString:@"com.apple.mobilesafari"]) { return NO; }
    
  @autoreleasepool {
    sFiksuLaunchUploaded = YES;

    NSString *query = [url query];
    // Based on one of the answers here:
    //   http://stackoverflow.com/questions/2225814/nsurl-pull-out-a-single-value-for-a-key-in-a-parameter-string
    //
    // Not necessarily the most robust solution, but Apple doesn't provide one natively.
    NSArray *kvPairs = [query componentsSeparatedByString:@"&"];
    NSMutableDictionary *valuesByKey = [NSMutableDictionary dictionary];
    for (NSString *pair in kvPairs) {
      NSArray *kvSplit = [pair componentsSeparatedByString:@"="];
      NSString *key = nil;
      NSString * value = nil;
      if ([kvSplit count] > 0) {
        key = [kvSplit objectAtIndex:0];
        key = [key stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
      }
      if ([kvSplit count] > 1) {
        value = [kvSplit objectAtIndex:1];
        value = [value stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
      }
      if (key != nil) {
        [valuesByKey setObject:value forKey:key];
      }
    }
    
    // We are done registering.
    sFiksuRegistering = NO;

    NSString *referredFiksuID = [valuesByKey objectForKey:@"fiksuid"];
    if (referredFiksuID) {
      [self storeFiksuID:referredFiksuID];
    }
    [valuesByKey removeObjectForKey:@"fiksuid"];
    // valuesByKey might contain such data as the referring ad
    [self uploadEvent:@"Conversion" withInfo:valuesByKey firstEvent:YES];
    // Upload a separate launch event to match server expectations
    [self uploadEvent:@"Launch" withInfo:nil firstEvent:NO];
  }
  return YES;
}

+ (NSString*)storedFiksuID {
  return [self localFiksuID];
}

@end
